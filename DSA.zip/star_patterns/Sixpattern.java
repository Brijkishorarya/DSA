package com.star_patterns;

import java.util.Scanner;

public class Sixpattern {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in); 
		int n = scanner.nextInt(); 
		
		int row = 1; 
		int n_dash = n - 1; 
		int nst = 1;
		while (row <= n) {
			
			//work 
			//print the dash 
			int i = 1; 
			while (i <= n_dash) {
				System.out.print("-" + " ");
				i = i + 1; 
			}
			//Print the Star
			int j = 1; 
			while (j <= nst) {
				System.out.print("*" + " ");
				j = j + 1; 
			}
			n_dash = n_dash - 1; 
			nst = nst + 1; 
			System.out.println();
			row = row + 1; 
		}
	}
}

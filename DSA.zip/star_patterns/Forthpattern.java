package com.star_patterns;

import java.util.Scanner;

public class Forthpattern {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in); 
		int n = scanner.nextInt(); 
		
		int nst = n; //No of Star in rowth
		int row = 1; 
		while (row <= n) {
			//work
			//print the star
			int i = 1; 
			while (i <= nst) {
				System.out.print("*" + " ");
				i = i + 1;  
			}
			
			// Preparation for next row
			System.out.println();
			nst = nst - 1; 
			row = row + 1; 
		}
	}
}

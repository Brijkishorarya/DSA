package com.star_patterns;

import java.util.Scanner;

public class Fifthpattern {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in); 
		int n = scanner.nextInt(); 
		
		int nst = 1; 
		int row = 1; 
		while (row <= n) {
			int i = 1; 
			while(i <= nst) {
//			while (i <= row) {
				System.out.print("*" + " ");
				i = i + 1; 
			}
			
			//prepation for next row 
			nst = nst + 1; //if not use comment second while uncomment third while
			System.out.println();
			row = row + 1; 
		}
	}
}

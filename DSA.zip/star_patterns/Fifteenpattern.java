package com.star_patterns;

import java.util.Scanner;

public class Fifteenpattern {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int n = scanner.nextInt(); 
		
		int row = 1; 
		int nst = 1; 
		
		while (row <= n * 2 - 1) {
			//work 
			//print no. of star  
			int i = 1; 
			while (i <= nst) {
				System.out.print("*" + " ");
				i = i + 1; 
			}
			//preparation for next row 
			if(row < n) {
				nst = nst + 1; 
			} else {
				nst = nst - 1; 
			}
			System.out.println();
			row = row + 1; 
		}
	}
}

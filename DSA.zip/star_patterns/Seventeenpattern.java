package com.star_patterns;

import java.util.Scanner;

public class Seventeenpattern {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in); 
		int n = scanner.nextInt(); 
		
		int row = 1; 
		int nst = n; 
		int n_space = 0;
		
		while (row <= n) {
			//work 
			//print no. of Left star 
			int i = 1; 
			while (i <= nst) {
				System.out.print("*" + " ");
				i = i + 1; 
			}
				
				//print no. of space
				int j = 1; 
				while (j <= n_space) {
					System.out.print(" " + " ");
					j = j + 1; 
				}
				
				//print no. of right star 
				int k = 1;	 
				while (k <= nst) {
					System.out.print("*" + " ");
					k = k + 1; 
				}
			//preparation for next row 
			nst = nst - 1; 
			n_space = n_space + 2; 
			System.out.println();
			row = row + 1; 
		}
	}
}

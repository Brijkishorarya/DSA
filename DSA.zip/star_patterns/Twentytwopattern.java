package com.star_patterns;

import java.util.Scanner;

public class Twentytwopattern {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in); 
		int n = scanner.nextInt(); 
		
		int row = 1; 
		int nsp = (n-1)/2; 
		int nst = 1; 
		int nsp2 = -1; 
		
		while (row <= n) {
			//work 
			//print no. of space 
			int i = 1; 
			while (i <= nsp) {
				System.out.print(" " + " ");
				i = i + 1; 
			}
			int j = 1; 
			while (j <= nst) {
				System.out.print("*" + " ");
				j = j + 1; 
			}
			if (row != 1 && row != n) {
				int k = 1; 
				while (k <= nsp2) {
					System.out.print(" " + " ");
					k = k + 1; 
				}
				int l = 1; 
				while (l <= nst) {
					System.out.print("*" + " ");
					l = l + 1;
				}
			}
			
			//preparation for next row
			if (row <= (n-1)/2) { 
				nsp = nsp - 1; 
				nsp2 = nsp2 + 2; 
			} else {
				nsp = nsp + 1; 
				nsp2 = nsp2 - 2; 
			}
			System.out.println();
			row = row + 1; 
		}
	}
}

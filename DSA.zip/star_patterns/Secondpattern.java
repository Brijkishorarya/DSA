package com.star_patterns;

import java.util.Scanner;

public class Secondpattern {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in); 
		int n = scanner.nextInt();  
		
		int row = 1; 
		while (row <= 2) {
			
			//work 
			int i = 1;  
			while (i <= n) {  
				System.out.print("*" + " ");
				i = i + 1;
			}
			System.out.println();
			row = row + 1; 
		}
	}
}

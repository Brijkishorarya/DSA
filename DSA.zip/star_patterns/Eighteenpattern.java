package com.star_patterns;

import java.util.Scanner;

public class Eighteenpattern {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();

        int row = 1;
        int nst = n-1;
        int nsp = n-2;

        while (row <= n) {
			if(row == 1 || row == n) {
				int i = 1; 
				while (i <= nst) {
					System.out.print("*" + " ");
					i = i + 1; 
				}
			}else {
				System.out.print("*" + " ");
			}
			
			if(row != 1 && row != n) {
				int j = 1;  
				while (j <= nsp) {
					System.out.print(" " + " ");
					j = j + 1; 
				}
			}
			System.out.print("*");
			System.out.println();
			row = row + 1; 
		}
    }
}

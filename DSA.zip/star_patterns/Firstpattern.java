package com.star_patterns;

import java.util.Scanner;

public class Firstpattern {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in); 
		int n = scanner.nextInt(); 
		
		int i = 1; 
		while (i <= n) {
			System.out.print('*' + " ");
//			i++; which one is better 
			i = i + 1; 
		}
	}
}

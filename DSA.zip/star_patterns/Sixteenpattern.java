package com.star_patterns;

import java.util.Scanner;

public class Sixteenpattern {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in); 
		int n = scanner.nextInt(); 
		
		int row = 1; 
		int nst = 1; 
		int nsp = n - 1; 
		
		while (row <= n * 2 - 1) {
			//work 
			//print no. of space 
			int i = 1; 
			while (i <= nsp) {
				System.out.print(" " + " ");
				i = i + 1; 
			}
			//print no. of star
			int j = 1; 
			while (j <= nst) {
				System.out.print("*" + " ");
				j = j + 1; 
			}
			//preparation for next row 
			if(row < n) {
				nsp = nsp - 1; 
				nst = nst + 1;
			} else {
				nsp = nsp + 1;
				nst = nst - 1;
			}
			System.out.println();
			row = row + 1; 
		}
	}
}

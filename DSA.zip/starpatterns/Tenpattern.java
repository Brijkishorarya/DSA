package com.starpatterns;

import java.util.Scanner;

public class Tenpattern {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in); 
		int n = scanner.nextInt(); 
		
		int row = 1;
		int n_space = n - 1; 
		int nst = 1; 
		while (row <= n) {
			//work 
			//print no. of space 			
			int i = 1; 
			while (i <= n_space) {
				System.out.print(" ");
				i = i + 1; 
			}
			//print no. of star 
			int j = 1; 
			while (j <= nst) {
				if(j % 2 == 0) {
					System.out.print("!");
				}
				else {
					System.out.print("*");
				} 
				j = j + 1;
			}
			
			//preparation for next row 
			n_space = n_space - 1; 
			nst = nst + 2; 
			System.out.println();
			row = row + 1;
		}
	}
}

package com.starpatterns;

import java.util.Scanner;

public class Thirdpattern {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in); 
		int n = scanner.nextInt(); 
		
		int row = 1;
		int nst = n;
		while (row <= n) {
			int i = 1; 
			while (i <= nst) {
				System.out.print("*");
				i = i + 1; 
			}
			System.out.println();
			row = row + 1; 
		}
	}
}

package com.starpatterns;

import java.util.Scanner;

public class Nineteenpattern {
	public static void main(String[] args) {
		        Scanner scanner = new Scanner(System.in);
		        int n = scanner.nextInt();

		        int row = 1;
		        int nsp1 = 1;
		        int nsp2 = n - 3;

		        while (row <= n) {
		            int i = 1;
		            while (i <= n) {
		                if (i == nsp1 || i == nsp2 + 2 || i == n - nsp1 + 1 || i == n - nsp2) {
		                    System.out.print("* ");
		                } else {
		                    System.out.print("  ");
		                }
		                i = i + 1;
		            }

		            System.out.println();

		            if (row <= n / 2) {
		                nsp1 = nsp1 + 2;
		                nsp2 = nsp2 - 2;
		            } else {
		                nsp1 = nsp1 - 2;
		                nsp2 = nsp2 + 2;
		            }

		            row = row + 1;
		        }
	}
}


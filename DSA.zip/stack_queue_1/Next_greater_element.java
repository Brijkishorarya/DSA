package com.stack_queue_1;

import java.util.Stack;

public class Next_greater_element {
	public static void main(String[] args) {
		int[] arr = {11, 9, 13, 21, 3}; 
		NGE(arr);
	}
	
	public static void NGE(int[] arr) {
		Stack<Integer> stack = new Stack<>(); 
		int[] ans = new int[arr.length]; 
		for (int i = 0; i < ans.length; i++) {
			while (!stack.isEmpty() && arr[i] > arr[stack.peek()]) {
				ans[stack.pop()] = arr[i]; 
			}
			stack.push(i); 
		}
		while(!stack.isEmpty()) {
			ans[stack.pop()] = -1; 
		}
		for(int i = 0; i < ans.length; i++) {
			System.out.println(arr[i] + " " + ans[i]);
		}
	}
}

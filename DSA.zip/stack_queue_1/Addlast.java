package com.stack_queue_1;

import java.util.Stack;

public class Addlast {
	public static void main(String[] args) {
		Stack<Integer> stack = new Stack<>(); 
		
		stack.push(2);
		stack.push(1);
		stack.push(3);
		stack.push(5);
		stack.push(7);
		
		System.out.println(stack);
		addlast(stack, -11); 
		System.out.println(stack);
	}
	
	public static void addlast(Stack<Integer> stack, int item) {
		if (stack.isEmpty()) {
			stack.push(item); 
			return; 
		}
		int x = stack.pop(); 
		addlast(stack, item);
		stack.push(x); 
	}
}


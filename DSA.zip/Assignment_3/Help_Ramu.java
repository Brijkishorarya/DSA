package com.Assignment_3; 
import java.util.Scanner;

public class Help_Ramu {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt(); 

        for (int i = 0; i < n; i++) {
            int c1 = scanner.nextInt();
            int c2 = scanner.nextInt();
            int c3 = scanner.nextInt();
            int c4 = scanner.nextInt();

            int n1 = scanner.nextInt(); 
            int m1 = scanner.nextInt(); 

            int[] rickshawCounts = new int[n1];
            int[] cabCounts = new int[m1];

            for (int j = 0; j < n1; j++) {
                rickshawCounts[j] = scanner.nextInt();
            }

            for (int j = 0; j < m1; j++) {
                cabCounts[j] = scanner.nextInt();
            }

            int totalRickshawCost = Math.min(
                    Math.min(sum(rickshawCounts, c1, c2), c3),
                    c4
            );

            int totalCabCost = Math.min(
                    Math.min(sum(cabCounts, c1, c2), c3),
                    c4
            );

            int finalCost = Math.min(totalRickshawCost + totalCabCost, c4);

            System.out.println(finalCost);
        }
    }

    private static int sum(int[] counts, int c1, int c2) {
        int total = 0;
        for (int count : counts) {
            total += Math.min(count * c1, c2);
        }
        return total;
    }
}

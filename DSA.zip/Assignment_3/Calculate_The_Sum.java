package com.Assignment_3;

import java.util.Scanner;

public class Calculate_The_Sum {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        long[] arr = new long[n];

        for (int i = 0; i < n; i++) {
            arr[i] = scanner.nextInt();
        }

        int q = scanner.nextInt();
        long mod = 1000000007;

        for (int i = 0; i < q; i++) {
            int x = scanner.nextInt();

            if (x == 0) {
                for (int j = 0; j < n; j++) {
                    arr[j] = (2 * arr[j]) % mod;
                }
            } else {
                long[] newArr = new long[n];
                for (int j = 0; j < n; j++) {
                    int index = (j - x + n) % n;
                    newArr[j] = (arr[j] + arr[index]) % mod;
                }
                arr = newArr;
            }
        }

        long sum = 0;
        for (long num : arr) {
            sum = (sum + num) % mod;
        }

        System.out.println(sum);
    }
}

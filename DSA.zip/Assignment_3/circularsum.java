package com.Assignment_3;

import java.util.Scanner;

public class circularsum {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in); 
		
		int n = scanner.nextInt(); 
		int[] arr = new int[n]; 
		int[] temp = new int[n]; 
		for (int i = 0; i < n; i++) {
			arr[i] = scanner.nextInt(); 
		}
		for (int i = 0; i < n; i++) {
			temp[i] = arr[i]; 
		}
		
		int q = scanner.nextInt(); 
		while (q --> 0) {
			int p = scanner.nextInt(); 
			for (int i = 0; i < n; i++) {
				int r = i - p; 
				if (r < 0) {
					r = n + r; 
				}
				arr[i] += temp[r]; 
			}
			for (int i = 0; i < n; i++) {
				temp[i] = arr[i]; 
			}
		}
		int sum = 0; 
		for (int i = 0; i < n; i++) {
			sum += arr[i]; 
		}
		System.out.println();
	}
}

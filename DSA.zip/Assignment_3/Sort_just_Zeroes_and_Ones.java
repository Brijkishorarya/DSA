package com.Assignment_3;

import java.util.Arrays;
import java.util.Scanner;

public class Sort_just_Zeroes_and_Ones {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in); 
		int n = scanner.nextInt(); 
		
		String[] sequenceStrings = new String[n]; 
		
		for (int i = 0; i < sequenceStrings.length; i++) {
			sequenceStrings[i] = scanner.next(); 
		}
		
		Arrays.sort(sequenceStrings);
		for (String seq : sequenceStrings) {
			System.out.print(seq + " ");
		}
	}
}

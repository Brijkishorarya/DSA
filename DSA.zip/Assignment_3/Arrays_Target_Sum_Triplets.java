package com.Assignment_3;

import java.util.*;

public class Arrays_Target_Sum_Triplets {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }
        int target = sc.nextInt();
        findTriplets(arr, target);
    }

    static void findTriplets(int arr[], int target) {
        // Sort the array
        Arrays.sort(arr);

        // Initialize a set to store unique triplets
        Set<String> triplets = new HashSet<>();

        // Iterate through the array
        for (int i = 0; i < arr.length - 2; i++) {
            int left = i + 1;
            int right = arr.length - 1;

            while (left < right) {
                int currSum = arr[i] + arr[left] + arr[right];

                if (currSum == target) {
                    triplets.add(arr[i] + ", " + arr[left] + " and " + arr[right]);
                    left++;
                    right--;
                } else if (currSum < target) {
                    left++;
                } else {
                    right--;
                }
            }
        }

        // Print the unique triplets in the desired order
        List<String> sortedTriplets = new ArrayList<>(triplets);
        Collections.sort(sortedTriplets);
        for (String triplet : sortedTriplets) {
            System.out.println(triplet);
        }
    }
}

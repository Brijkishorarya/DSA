package com.Assignment_3;


import java.util.Scanner;

public class Alex_Goes_Shopping {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in); 
		int n = scanner.nextInt(); 
		int[] prices = new int[n]; 
		
		for(int i = 0; i < n; i++) {
			prices[i] = scanner.nextInt(); 
		}
		
		int q = scanner.nextInt(); 
		for (int i = 0; i < q; i++) {
			int A = scanner.nextInt(); 
			int K = scanner.nextInt(); 
			
			int count = 0; 
			for(int price : prices) {
				if(A % price == 0) {
					count++; 
				}
			}
			
			if(count >= K) {
				System.out.println("Yes");
			} else {
				 System.out.println("No");
			}
		}
	}
}
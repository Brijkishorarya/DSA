package com.Assignment_3;

import java.util.Scanner;

public class Von_Neuman_Loves_Binary {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in); 
		int n = scanner.nextInt();
		
		int[] arr = new int[n]; 
		
		for(int i = 0; i < arr.length; i++) {
			String binarySequence = scanner.next(); 
			int decimalEquivalent = convertBin_to_Dec(binarySequence); 
			System.out.println(decimalEquivalent);
		}
	}
	
	public static int convertBin_to_Dec(String binary) {
		int ans = 0;
		int mul = 1; 
		
		for(int i = binary.length() - 1; i >= 0; i--) {
			char digit = binary.charAt(i); 
			if (digit == '1') {
				ans += mul; 
			}
			mul *= 2; 
		}
		
		return ans; 
	}
}

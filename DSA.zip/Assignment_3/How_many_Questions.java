package com.Assignment_3;

import java.util.Scanner;

public class How_many_Questions {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in); 
		
		int n = scanner.nextInt(); 
		int contest = 0; 
		
		for (int i = 0; i < n; i++) {
			int p = scanner.nextInt(); 
			int v = scanner.nextInt(); 
			int t = scanner.nextInt(); 
			
			if (p + v + t >= 2) {
				contest++; 
			}
		}
		System.out.println(contest);
	}
}

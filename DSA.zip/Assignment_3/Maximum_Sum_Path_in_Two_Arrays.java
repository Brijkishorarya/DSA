package com.Assignment_3;

import java.util.Scanner;

public class Maximum_Sum_Path_in_Two_Arrays {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in); 
		int t = scanner.nextInt(); 
		for (int i = 0; i < t; i++) {
			int a = scanner.nextInt(); 
			int b = scanner.nextInt(); 
			
			int [] arr1 = new int[a]; 
			int [] arr2 = new int[b]; 
			
			for (int j = 0; j < arr1.length; j++) {
				arr1[j] = scanner.nextInt(); 
			}
			for (int j = 0; j < arr2.length; j++) {
				arr2[j] = scanner.nextInt(); 
			}
			System.out.println(Max_sum_path(arr1, arr2));
		}
	}
	
	public static int Max_sum_path(int[] arr1, int[] arr2) {
		int i = 0, j = 0; 
		int result = 0, sum1 = 0, sum2 = 0; 
		
		while (i < arr1.length && j < arr2.length) {
			if(arr1[i] < arr2[j]) {
				sum1 += arr1[i++]; 
			} else if (arr1[i] > arr2[j]) {
				sum2 += arr2[j++]; 
			}
			else {
				result += Math.max(sum1, sum2) + arr1[i]; 
				i++; 
				j++; 
				sum1 = 0; 
				sum2 = 0; 
			}
		}
		
		while (i < arr1.length) {
			sum1 += arr1[i++]; 
		}
		
		while (j < arr2.length) {
			sum2 += arr2[j++]; 
		}
		
		result += Math.max(sum1, sum2); 
		
		return result; 
	}
}

package com.Assignment_3;

import java.util.Scanner;

public class Product_of_Array_Except_Self {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        int[] arr = new int[n];

        for (int i = 0; i < n; i++) {
            arr[i] = scanner.nextInt();
        }

        int[] ans = productExceptSelf(arr);

        for (int i = 0; i < ans.length; i++) {
            System.out.print(ans[i] + " ");
        }
    }
    
    public static int[] productExceptSelf(int[] nums) {
        int[] ans = new int[nums.length]; 
        int leftProd = 1; 
        for(int i = 0; i < nums.length; i++){
            ans[i] = leftProd; 
            leftProd *= nums[i]; 
        }
        int rightProd = 1; 
        for(int i = nums.length-1; i >= 0; i--){
            ans[i] *= rightProd; 
            rightProd *= nums[i]; 
        }
        return ans; 
    }
}

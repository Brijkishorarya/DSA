package com.Assignment_3;

import java.util.Scanner;

public class Pair_of_Roses {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in); 
		int T = s.nextInt();
		for(int i = 0; i<T ; i++) {
			int N = s.nextInt();
			int arr [] = new int[N];
			for(int j = 0; j<N ; j++ ) {
				arr[j] = s.nextInt();
			}
			int d = s.nextInt();   
			Deepak(arr,d);
		}
	}
		public static void Deepak(int arr[], int d) {
		    int n = arr.length;
		    int minDiff = Integer.MAX_VALUE;
		    int firstRose = 0;
		    int secondRose = 0;

		    for (int i = 0; i < n; i++) {
		        for (int j = i + 1; j < n; j++) { // Start j from i+1 to avoid checking the same pair twice
		            if (arr[i] + arr[j] == d) {
		                int diff = Math.abs(arr[i] - arr[j]);
		                if (diff < minDiff) {
		                    minDiff = diff;
		                    firstRose = arr[i] < arr[j] ? arr[i] : arr[j];
		                    secondRose = arr[i] < arr[j] ? arr[j] : arr[i];
		                }
		            }
		        }
		    }
		    System.out.println("Deepak should buy roses whose prices are " + firstRose + " and " + secondRose + ".");
		}
}
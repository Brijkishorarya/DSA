package com.Assignment_3;

import java.util.Scanner;

public class Running_Sum_of_the_Array {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in); 
		
		int n = scanner.nextInt(); 
		int[] arr = new int[n]; 
		int sum = 0; 
		
		for (int i = 0; i < arr.length; i++) {
			arr[i] = scanner.nextInt(); 
		}
		
		for (int i = 0; i < arr.length; i++) {
			 sum += arr[i]; 
			 System.out.print(sum + " ");
		}
	}
}

package com.Assignment_3;

import java.util.Scanner;

public class Arrays_Max_Value_In_Array {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in); 
		
		int n = scanner.nextInt(); 
		int[] arr = new int[n]; 
		
		for (int i = 0; i < arr.length; i++) {
			arr[i] = scanner.nextInt(); 
		}
		System.out.println(max_value(arr));
	}
	
	public static int  max_value(int[] arr) {
		int maxVal = arr[0]; 
		for (int i = 1; i < arr.length; i++) {
			if (arr[i] > maxVal) {
				maxVal = arr[i]; 
			} 
		}
		return maxVal; 
	} 
}

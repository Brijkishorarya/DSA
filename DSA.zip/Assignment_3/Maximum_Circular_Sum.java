package com.Assignment_3; 

import java.util.Scanner;

public class Maximum_Circular_Sum {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int t = scanner.nextInt();
        for (int i = 0; i < t; i++) {
            int n = scanner.nextInt();
            int[] arr = new int[n];
            for (int j = 0; j < n; j++) {
                arr[j] = scanner.nextInt();
            }
            System.out.println(maximumCircularSum(arr));
        }
    }

    public static int maximumCircularSum(int[] arr) {
        int max_straight_sum = kadane(arr);
        int max_circular_sum = 0;
        for (int i = 0; i < arr.length; i++) {
            max_circular_sum += arr[i];
            arr[i] = -arr[i];
        }
        max_circular_sum += kadane(arr);
        return (max_circular_sum > max_straight_sum) ? max_circular_sum : max_straight_sum;
    }

    public static int kadane(int[] arr) {
        int max_so_far = arr[0];
        int max_ending_here = arr[0];
        for (int i = 1; i < arr.length; i++) {
            max_ending_here = Math.max(arr[i], max_ending_here + arr[i]);
            max_so_far = Math.max(max_so_far, max_ending_here);
        }
        return max_so_far;
    }
}

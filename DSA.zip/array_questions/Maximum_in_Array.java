package com.array_questions;

public class Maximum_in_Array {
	public static void main(String[] args) {
		int[] arr = {3, 5, 1, 7, 8, 6}; 
		System.out.println(max_number(arr));
		System.out.println(max_number2(arr));
	}
	
	public static int max_number2(int[] arr) {
		int m = Integer.MIN_VALUE;
		for (int i = 0; i < arr.length; i++) {
			m = Math.max(m, arr[i]);
		}
		return m; 
	}
	
	public static int max_number(int[] arr) {
		int m = arr[0];
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] > m) {
				m = arr[i];
			}
		}
		return m; 
	}
}

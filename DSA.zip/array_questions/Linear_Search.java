package com.array_questions;

import java.util.Scanner;

public class Linear_Search {
	public static void main(String[] args) {
		int[] arr = { 3, 5, 1, 7, 8}; 
		Scanner scanner = new Scanner(System.in); 
		int item = scanner.nextInt(); 
		System.out.println(Search(arr, item));
	}
	
	public static int Search(int[] arr, int item) {
		for (int i = 0; i < arr.length; i++) {
			if (item == arr[i]) {
				return i;
			}
		}
		return -1; 
	}
}

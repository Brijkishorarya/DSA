package com.contest;

import java.util.Scanner;

public class Second {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in); 
		
		int row = scanner.nextInt(); 
		int col = scanner.nextInt(); 
		
		for (int i = 1; i <= row; i++) {
			for (int j = 1; j <= col; j++) {
				if((i % 4 == 0 && j == 1) || (i % 2 != 0) || (i % 4 != 0 && j == col)) {
					System.out.print("#");
				} else {
					System.out.print(".");
				}
			}
			System.out.println();
		}
	}
}

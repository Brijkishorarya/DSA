package com.contest;

public class First {

}

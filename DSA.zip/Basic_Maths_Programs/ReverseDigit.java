package com.Basic_Maths_Programs;

import java.util.Scanner;

public class ReverseDigit {
	public static void main(String[] args) {
		int reverse = 0; 
		Scanner scanner = new Scanner(System.in); 
		
		int n = scanner.nextInt(); 
		while (n > 0) {
			int remider = n % 10; 
			reverse = reverse * 10 + remider; 
			n = n / 10; 
		}
		System.out.println(reverse);
	}
}

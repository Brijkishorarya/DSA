package com.Basic_Maths_Programs;

import java.util.Scanner;

public class GCD {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in); 
		
		System.out.println("Enter dividend value");
		int dividend = scanner.nextInt(); 
		System.out.println("Enter divisor value");
		int divisor = scanner.nextInt(); 
		
		while (dividend % divisor != 0) {
			int reminder = dividend % divisor;
			dividend = divisor; 
			divisor = reminder; 
		}
		System.out.println("it is GCD of " + divisor);
	}
}

package com.String;

import java.util.Iterator;

public class Unique_Char_String {
	public static void main(String[] args) {
		String string = "codingblock"; 
		System.out.println(Unique(string));
	}
	public static boolean Unique(String string) {
		int[] frq = new int[26]; 
		for (int i = 0; i < string.length(); i++) {
			int idx = string.charAt(i) - 'a'; 
			frq[idx]++; 
		}
		
		for (int i = 0; i < frq.length; i++) {
			if (frq[i] > 1) {
				return false; 
			}
		}
		return true; 
	}
}

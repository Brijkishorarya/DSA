package com.String;

public class Reverse_Words_in_a_String {
	public static void main(String[] args) {
		String string = "      hello     world    bye    india      cows   "; 
		string = string.trim(); 
		String[] arr = string.split(" +"); 
		String ans = ""; 
		for (int i = arr.length - 1; i >= 0; i--) {
			ans += arr[i] + " "; 
		}
		System.out.println(ans.trim());
	}
}

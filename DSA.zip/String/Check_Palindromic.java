package com.String;

import java.util.Scanner;

public class Check_Palindromic {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in); 
		String string = scanner.nextLine(); 
		
		System.out.println(Palindrome(string));
	}
	
	public static boolean Palindrome(String string) {
		int i = 0; 
		int j = string.length()-1; 
		
		while (i < j) {
			if (string.charAt(i) != string.charAt(j)) {
				return false; 
			}
			i++; 
			j--; 
		}
		return true; 
	}
}

package com.String;

import java.util.Iterator;

public class String_LexcoGraphic_Order {
	public static void main(String[] args) {
		String string1 = "kunal"; 
		String string2 = "komal"; 
		String string3 = "tanmay"; 
		System.out.println(string1.compareTo(string2));
		System.out.println(string2.compareTo(string3));
		System.out.println(compareTo(string1, string2));
	}
	
	public static int compareTo(String string1, String string2) {
		if (string1 == string2) {
			return 0; 
		}
		int l1 = string1.length(); 
		int l2 = string2.length(); 
		int n = Math.min(l1, l2); 
		for (int i = 0; i < n; i++) {
			if (string1.charAt(i) != string2.charAt(i)) {
				return string1.charAt(i) - string2.charAt(i); 
			}
		}
		
		return l1 - l2; 
	}
}

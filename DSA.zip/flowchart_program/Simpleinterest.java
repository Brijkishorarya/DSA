package com.flowchart_program;

import java.util.Scanner;

public class Simpleinterest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter your amount");
		Scanner scanner = new Scanner(System.in); 
		int value = scanner.nextInt(); 
		
		float interest = (value*2*1)/100; 
		System.out.println(interest);
	}

}

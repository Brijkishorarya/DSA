package com.flowchart_program;

import java.util.Scanner;

public class Evenorodd {
	public static void main(String[] args) {
		System.out.println("Enter your number which you want to check it is evern or odd");
		Scanner scanner = new Scanner(System.in);
		int value = scanner.nextInt(); 
		if(value % 2 == 0) {
			System.out.println("Number is even");
		}else {
			System.out.println("Number is odd");
		}
	}
}

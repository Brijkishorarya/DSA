package com.flowchart_program;

import java.util.Scanner;

public class Threemax {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in); 
		int a = scanner.nextInt(); 
		int b = scanner.nextInt(); 
		int c = scanner.nextInt(); 
		if(a > b && a > c) {
			System.out.println("a is greater then b & c");
		}
		else if(b > c) {
			System.out.println("b is greather than a & c");
		}
		else {
			System.out.println("c is greather than b & c");
		}
//		if (c > a && c > b) {
//			System.out.println("c is greather than b & c");
//		}
	}
}

package com.flowchart_program;

import java.util.Scanner;

public class Pattern {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		int n = scanner.nextInt();

		int i = 1;
		while (i <= n) {
			System.out.println("*");
		}
		i++;
	}

}

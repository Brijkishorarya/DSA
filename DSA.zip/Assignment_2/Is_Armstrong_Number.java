package com.Assignment_2;

import java.util.Scanner;

public class Is_Armstrong_Number {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in); 
        int number = scanner.nextInt();

        boolean isArmstrong = checkArmstrong(number);
        System.out.println(isArmstrong);
    }

    public static boolean checkArmstrong(int num) {
        int originalNum = num;
        int numDigits = String.valueOf(num).length();
        int sum = 0;

        while (num > 0) {
            int digit = num % 10;
            sum += Math.pow(digit, numDigits);
            num /= 10;
        }

        return sum == originalNum;
	}
}

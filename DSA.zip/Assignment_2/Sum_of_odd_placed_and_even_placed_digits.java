package com.Assignment_2;

import java.util.Scanner;

public class Sum_of_odd_placed_and_even_placed_digits {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in); 
		
		int n = scanner.nextInt(); 
		
		int evenPossum = 0; 
		int oddPossum = 0; 
		int currPos = 1; 
		
		while (n > 0) {
			int digit = n % 10; 
			if (currPos % 2 == 0) {
				evenPossum += digit; 
			} else {
				oddPossum += digit; 
			}
			currPos++; 
			n /= 10; 
		}
		System.out.println(oddPossum);
		System.out.println(evenPossum);
	}
}

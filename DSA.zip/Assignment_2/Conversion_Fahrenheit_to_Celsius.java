package com.Assignment_2;

import java.util.Scanner;

public class Conversion_Fahrenheit_to_Celsius {
	public static void main(String[] args) {
		
        Scanner scanner = new Scanner(System.in); 
        
        int min = scanner.nextInt();
        int max = scanner.nextInt();
        int step = scanner.nextInt();
       
        for (int fahrenheit = min; fahrenheit <= max; fahrenheit += step) {
            int celsius = (int) ((5.0 / 9.0) * (fahrenheit - 32)); 
            System.out.println(fahrenheit + "\t" + Math.round(celsius));
        }
	}
}

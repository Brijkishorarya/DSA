package com.Assignment_2;

import java.util.Scanner;

public class Count_Digits {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt(); 
        int digit = scanner.nextInt(); 
        int occurencedigit = 0; 
        
        while (n > 0) {
			int rem = n % 10; 
			if (digit == rem) {
				occurencedigit++; 
			}
			n /= 10; 
		}
        System.out.println(occurencedigit);
    }
}

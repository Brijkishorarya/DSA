package com.Assignment_2;

import java.util.Iterator;
import java.util.Scanner;

public class Check_prime {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		int n = scanner.nextInt(); 
		if (n <= 1) {
			System.out.println("Not Prime");
			return; 
		}
		for (int i = 2; i <= Math.sqrt(n); i++) {
			if (n % i == 0) {
				System.out.println("Not Prime");
				return; 
			}
		}
		System.out.println("Prime");
	}
}

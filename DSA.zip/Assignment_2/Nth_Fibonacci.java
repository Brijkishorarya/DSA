package com.Assignment_2;

import java.util.Scanner;

public class Nth_Fibonacci {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in); 
		int n = scanner.nextInt(); 
		
		int a = 0; 
		int b = 1; 
		int c = 0; 
		
		for(int i = 0; i < n; i++) {
			c = a + b; 
			a = b; 
			b = c; 
		}
		System.out.println(a);
	}
}

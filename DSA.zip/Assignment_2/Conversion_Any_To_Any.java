package com.Assignment_2;

import java.util.Scanner;

public class Conversion_Any_To_Any {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		int sb = scanner.nextInt(); 
		int db = scanner.nextInt(); 
		String sn = scanner.next(); 
		
		String resultString = convertBase(sn, sb, db); 
		System.out.println(resultString);
	}
	
	public static String convertBase(String sn, int sb, int db) {
		int decimalValue = Integer.parseInt(sn, sb); 
		
		String destinationvalue = Integer.toString(decimalValue, db); 
		
		return destinationvalue; 
	}
}

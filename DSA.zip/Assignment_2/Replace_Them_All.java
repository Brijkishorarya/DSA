package com.Assignment_2;

import java.util.Scanner;

public class Replace_Them_All {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		long n = scanner.nextLong(); 
		
		long result = replaceZeroWithFives(n); 
		System.out.println(result);
		
	}
	
	public static long replaceZeroWithFives(long num) {
		String numString = Long.toString(num); 
		String numsStr = Long.toString(num); 
		
		numsStr = numString.replace('0', '5');
		return Long.parseLong(numsStr); 
	}
}

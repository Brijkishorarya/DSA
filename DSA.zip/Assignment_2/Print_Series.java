package com.Assignment_2;

import java.util.Scanner;

public class Print_Series {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in); 
		
		int n1 = scanner.nextInt(); 
		int n2 = scanner.nextInt(); 
		
		int count = 0; 
		int i = 1; 
		
		while (count < n1) {
			int term = 3 * i + 2; 
			if (term % n2 != 0) {
				System.out.println(term);
				count++; 
			}
			i++;  
		}
	}
}

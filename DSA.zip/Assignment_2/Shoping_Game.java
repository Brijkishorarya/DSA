package com.Assignment_2;

import java.util.Scanner;

public class Shoping_Game {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();

        while(n!=0)
        {
            //maximum smartphone purchase
            int ayushMax = sc.nextInt();
            int harshitMax = sc.nextInt();
            //Mehod call
            purchaseSmartphone(ayushMax, harshitMax);
            n--;
        }
    }
    static void purchaseSmartphone(int m, int n)
    {
        
        
        int currentSmartphone = 1;
        int harshit = 0;
        int aayush = 0;
        while(true)
        {
            aayush = aayush + currentSmartphone;
            currentSmartphone++;
            harshit = harshit + currentSmartphone;
            currentSmartphone++;
            if(aayush>m)
            {
                System.out.println("Harshit");
                break;
            }
            else if(harshit>n)
            {
                System.out.println("Aayush");
                break;
            }
        }
    }
}


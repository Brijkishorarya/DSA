package com.Assignment_2;

import java.util.Scanner;

public class LCM {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in); 
		int a = scanner.nextInt(); 
		int b = scanner.nextInt(); 
		
		int ans = (a > b) ? a : b; 
		while (true) {
			if(ans % a == 0 && ans % b == 0) {
				break; 
			}
			ans++; 
		}
		System.out.println(ans);
	}
}

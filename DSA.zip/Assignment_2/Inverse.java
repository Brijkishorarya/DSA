package com.Assignment_2;

import java.util.Scanner;

public class Inverse {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in); 
		int n = scanner.nextInt(); 
		System.out.println(inverse(n));
	}
	
	public static int inverse(int n) {
		int sum = 0; 
		int pos = 1; 
		while (n != 0) {
			int rem = n % 10; 
			sum = (int) (sum + pos * Math.pow(10,  rem-1));
			n /= 10; 
			pos++; 
		}
		return sum; 
	}
}

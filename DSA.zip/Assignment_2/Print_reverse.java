package com.Assignment_2;

import java.util.Scanner;

public class Print_reverse {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in); 
		int n = scanner.nextInt(); 
		
		int rem = 0; 
		while (n > 0) {
			int digit = n % 10; 
			rem = digit; 
			n = n / 10; 
			System.out.print(rem);
		}
	}
}

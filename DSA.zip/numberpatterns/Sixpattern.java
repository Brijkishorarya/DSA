package com.numberpatterns;

import java.util.Scanner;

public class Sixpattern {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in); 
		int n = scanner.nextInt(); 
		
		int row = 1; 
		int nsp = n - 1; 
		int nst = 1; 
		int row_val = 1; 
		while (row <= n) {
			
			//print no. of space 
			int i = 1; 
			while (i <= nsp) {
				System.out.print(" " + " ");
				i = i + 1; 
			}
			//print no. of no. 
			int j = 1; 
			int col_val = row_val; 
			while (j <= nst) {
				System.out.print(col_val + " ");
				if (j < (nst+1)/2) {
					col_val = col_val + 1; 
				} else {
					col_val = col_val - 1;
				}
				j = j + 1; 
			}
			//preparation for next row 
			nsp = nsp - 1; 
			nst = nst + 2;  
			System.out.println();
			row = row + 1; 
		}
	}
}

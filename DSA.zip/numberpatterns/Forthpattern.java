package com.numberpatterns;

import java.util.Scanner;

public class Forthpattern {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in); 
		int n = scanner.nextInt(); 
		
		int row = 1; 
		int nsp = n - 1; 
		int npn = 1; 
		int no = 1;
		
		while (row <= n) { 
			//work 
			//print no. of space 
			int i = 1; 
			while (i <= nsp) {
				System.out.print(" " + " ");
				i = i + 1; 
			}
			//print no. of no. pattern 
			int j = 1; 
			while (j <= npn) {
				System.out.print(no + " ");
				j = j + 1; 
				no = no + 1;  
			}
			//preparation for next row 
			nsp = nsp - 1; 
			npn = npn + 2; 
			System.out.println();
			row = row + 1; 
			no = 1; 
		}
	}
}

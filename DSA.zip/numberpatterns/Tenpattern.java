package com.numberpatterns;

import java.util.Scanner;

public class Tenpattern {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in); 
		int n = scanner.nextInt(); 
		
		int row = 1; 
		int nst = n-1;
		int nst1 = 1; 
		
		while (row <= n) {
			//work 
			//print no. of star no. 
			int i = 1; 
			while (i <= n) {
				System.out.print(nst + " ");
				i++;
				nst--; 
			}
			System.out.println();
			row++; 
			nst = n;
		}
	}
}

package com.inheritance;

public class Client {
	public static void main(String[] args) {
		P objP = new P(); 
//		C objC = new C(); 
		//case - 1
//		System.out.println(objP.d);
//		System.out.println(objP.d1);
//		objP.fun();
//		objP.fun1();
		
		//case - 2 
		C objC = new C(); 
		
	}
}

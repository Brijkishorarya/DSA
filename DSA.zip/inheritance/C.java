package com.inheritance;

public class C extends P{
	int d = 2; 
	int d1 = 20; 
	
	public void fun() {
		System.out.println("Fun in C");
	}
	
	public void fun1() {
		System.out.println("Fun1 in C");
	}
}

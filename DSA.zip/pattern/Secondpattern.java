package com.pattern;

import java.util.Scanner;

public class Secondpattern {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in); 
		
		int n = scanner.nextInt(); 
		int row = 1; 
		int nst = 1; //No of start in rowth
		
		while (row <= n) {
			int s = 1; 
			int i = 1; 
			while(s <= n - row) {
				System.out.print(" ");
				s++;  
			}
			while(i <= nst) {
				System.out.print("* ");
				i = i + 1; 
				
			}
			System.out.println();
			row = row+1; 
			nst++; 
		}
	}
}

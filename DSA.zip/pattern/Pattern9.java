package com.pattern;

import java.util.Scanner;

public class Pattern9 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in); 
		
		int n = scanner.nextInt(); 
		int row = 1; 
		int nst = 1; 
		int nsp = n-1; 
		while(row <= n) {
			int i = 1; 
			
		}
	}
}

package com.pattern;

import java.util.Scanner;

public class Fivepattern {
	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in); 
		
		int n = scanner.nextInt(); 
		int row = 1; 
		int nst = n; 
		int nsp = 0; 
		
		while(row <= n) {
			//work 
			
			
			//print the space 
			int i = 1; 
			while(i <= nsp) {
				System.out.print(" ");
				i = i + 1; 
			}
			//print the star
			
			int j = 1; 
			while(j <= nst) {
				System.out.print("*");
				j = j + 1; 
			}
			
			//preparation for next row 
			nsp = nsp + 2; 
			nst = nst -1; 
			System.out.println();
			row = row+1; 
			
			
			
			row = row + 1; 
		}
	}
}

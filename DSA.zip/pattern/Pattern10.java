package com.pattern;

import java.util.Scanner;

public class Pattern10 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in); 
		
		int n = scanner.nextInt(); 
		
		int row = 1; 
		int nsp = 0; 
		int nst = 2 * n-1; 
		while(row<=n) {
			//print the Space 
			int i = 1; 
			while(i<=nsp) {
				System.out.print(" "+" ");
				i = i + 1; 
			}
			
			//Print the star 
			int j = 1; 
			while(j<=nst) {
				System.out.print("*"+" ");
				j = j + 1; 
			}
			
			nst = nst - 2; 
			nsp = nsp + 1;
			System.out.println();
			row = row + 1;
		}
	}
}

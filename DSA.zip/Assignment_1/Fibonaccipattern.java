package com.Assignment_1;

import java.util.Scanner;

public class Fibonaccipattern {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in); 
		int n = scanner.nextInt(); 
		
		int row = 1;
		int nst = 1; 
		int a = 0; 
		int b = 1; 
		int c; 
		
		while (row <= n) {
			//work 
			//print no. of no. 
			int i = 1;
			while (i <= nst) {
				System.out.print(a + "\t");
				c = a + b; 
				a = b; 
				b = c; 
				i++; 
			}
			//preparation for next row 
			nst++; 
			System.out.println();
			row++; 
		}
	}
}

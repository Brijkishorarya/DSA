package com.Assignment_1;

import java.util.Scanner;

public class PatternInvertedHourGlass {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in); 
		int n = scanner.nextInt(); 
		
		int row = 1 ; 
		int nst = 1; 
		int nsp = (n*2)-1;
		int row_value = n; 
		
		while (row <= (n*2)+1) {
			//work 
			//print no. left of no. 
			int i = 1; 
			int col_value = row_value; 
			while (i <= nst) {
				System.out.print(col_value + " ");
				col_value--; 
				i++; 
			}
			//print no. of space 
			int j = 1; 
			while (j <= nsp) {
				System.out.print(" " + " ");
				j++; 
			}
			//print no. of right no. 
			int k = 1;
			if (row == n + 1) {
				k = 2; 
				col_value++;
			}
			int col_value2 = col_value+1; 
			while (k <= nst) {
				System.out.print(col_value2 + " ");
				col_value2++; 
				k++; 
			}
			//preparation for next row 
			if(row < (n+1)) {
				nst++; 
				nsp = nsp - 2;
			} else {
				nst--; 
				nsp = nsp + 2; 
			}
			System.out.println();
			row++; 
		}
	}
}

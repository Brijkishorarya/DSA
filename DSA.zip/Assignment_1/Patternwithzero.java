package com.Assignment_1;

import java.util.Scanner;

public class Patternwithzero {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int n = scanner.nextInt(); 
		
		int row = 1; 
		int nst = 1; 
		int row_value = 1; 
		
		while (row <= n) {
			//work 
			//print no. of no.
			int i = 1; 
			int col_value = row_value;
			while (i <= nst) {
				if (i == 1 || i == nst) {
					System.out.print(col_value + "\t");
				} else {
					System.out.print("0" + "\t");
				} 
				i++; 
			}
			//preparation for next row 
			nst++; 
			row_value++; 
			System.out.println();
			row++; 
		}
	}
}

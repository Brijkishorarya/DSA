package com.Assignment_1;

import java.util.Scanner;

public class Patterndoublesidedarrow {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in); 
		int n = scanner.nextInt(); 
		
		int row = 1; 
		int nst = 1; 
		int nsp1 = n-1; 
		int nsp2 = -1;
		int row_value = 1; 
		int row_value2 = 1; 
		
		while (row <= n) {
			//work 
			//print no. of left space
			int i = 1; 
			while (i <= nsp1) {
				System.out.print(" " + " ");
				i++; 
			}
			
			//print no. of left no. 
			int j = 1; 
			int col_value = row_value;
			while (j <= nst) {
				System.out.print(col_value + " ");
				col_value--; 
				j++; 
			}
			
			//print no. of center space 
			int k = 1; 
			while (k <= nsp2) {
				System.out.print(" " + " ");
				k++; 
			}
			
//			//print no. right no. 
			int l = 1; 
			int col_value2 = row_value2; 
			while (l <= nst ) {
				if (row == 1 || row == n) {
					System.out.print("");
				} else {
					System.out.print(col_value2 + " ");
					col_value2++; 
				}
				l++; 
			}
			//preparation for next row 
			if (row < (n+1)/2) {
				nst++; 
				nsp1 = nsp1 - 2;
				row_value++;
				nsp2 = nsp2 + 2; 
			} else {
				nst--; 
				nsp1 = nsp1 + 2;
				row_value--;
				nsp2 = nsp2 - 2; 
			}
			System.out.println();
			row++; 
		}
	}
}

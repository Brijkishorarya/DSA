package com.Assignment_1;

import java.util.Scanner;

public class Patternmountain {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in); 
		int n = scanner.nextInt(); 
		
		int row = 1; 
		int nst = 1; 
		int nsp = (n * 2) - 3; 
		int row_value = 1; 
		
		while (row <= n) {
			//work 
			//print no. of left no. 
			int i = 1; 
			int col_value = row_value; 
			while (i <= nst) {
				System.out.print(col_value + "\t");
				col_value++; 
				i++; 
			}
			//print no. of space 
			int j = 1; 
			while (j <= nsp) {
				System.out.print(" " + "\t");
				j++; 
			}
			//print no. of right no. 
			int col_value2;  
			int k = 1; 
			if (nst == n) {
				 col_value2 = col_value - 2;  
			}
			else {
				 col_value2 = col_value - 1;
			}
			if (row == n) {
				k = 2; 
			} 
			while (k <= nst) {
				System.out.print(col_value2 + "\t");
				col_value2--;
				k++; 
			}
			//preparation for next row ; 

			nst++;
			nsp = nsp - 2; 
			System.out.println();
			row++;
		}
	}
}

package com.Assignment_1;

import java.util.Scanner;

public class PatternHourGlass {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in); 
		int n = scanner.nextInt(); 
		
		int row = 1; 
		int nst = (n*2) + 1;
		int nsp = 0; 
		int row_val = n; 
		
		while (row <= (n*2)+1) {
			//work 
			//print no. of space 
			int i = 1; 
			while (i <= nsp) {
				System.out.print(" " + " ");
				i++; 
			}
			
			//print no. of no. 
			int j = 1; 
			int col_val = row_val; 
			while (j <= nst) {
				System.out.print(col_val + " ");
				if (j < (nst+1)/2) {
					col_val--; 
				}else {
					col_val++; 
				}
				j++; 
			}
			
			//preparation for next row 
			if (row < n + 1) {
				row_val--; 
				nsp++;
				nst = nst - 2; 
			} else {
				row_val++; 
				nsp--; 
				nst = nst + 2; 
			}
			System.out.println();
			row++; 
		}
	}
}

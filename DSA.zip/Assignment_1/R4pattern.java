package com.Assignment_1;

import java.util.Scanner;

public class R4pattern {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in); 
		int n = scanner.nextInt(); 
		
		int row = 1; 
		int nst = 1; 
		
		while (row <= n) {
			//work 
			//print no. of star 
			int i = 1; 
			while (i <= nst) {
				System.out.print("*");
				i = i + 1; 
			}
			//preparation for next row 
			nst++; 
			System.out.println();
			row++; 
		}
	}
}

package com.Assignment_1;

import java.util.Scanner;

public class Rombuspattern {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in); 
		int n = scanner.nextInt(); 
		
		int row = 1; 
		int nsp = n - 1; 
		int nst = 1; 
		int row_val = 1; 
		while (row <= 2 * n - 1) {
			
			//print no. of space 
			int i = 1; 
			while (i <= nsp) {
				System.out.print(" " + "\t");
				i = i + 1; 
			}
			//print no. of no. 
			int j = 1; 
			int col_val = row_val; 
			while (j <= nst) {
				System.out.print(col_val + "\t");
				if (j < (nst+1)/2) {
					col_val = col_val + 1; 
				} else {
					col_val = col_val - 1;
				}
				j = j + 1; 
			}
			//preparation for next row 
			if (row < n) {
				nsp = nsp - 1; 
				nst = nst + 2; 
				row_val = row_val + 1; 
			} else {
				nsp = nsp + 1; 
				nst = nst - 2; 
				row_val = row_val - 1; 
			}
			System.out.println();
			row = row + 1; 
		}
	}
}

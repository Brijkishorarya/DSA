package com.Assignment_1;

import java.util.Scanner;


public class Pascaltriablepattern {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();

        int row = 0; 
        int nst = 1;  
        
        while (row < n) {
        	
        	//print the Star 
        	int i = 0; 
        	int ncr = 1; 
        	while (i < nst) {
				System.out.print(ncr + "\t");
				//Preparation for Next ncr 
				ncr = ((row-i) * (ncr)) /(i + 1); 
				i++; 
			}
        	//Preparation for next row 
        	nst++; 
        	System.out.println();
        	row++; 
		}
    }
}

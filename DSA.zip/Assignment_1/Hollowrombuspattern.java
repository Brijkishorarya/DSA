package com.Assignment_1;

import java.util.Scanner;

public class Hollowrombuspattern {
	 public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        int n = scanner.nextInt();

	        int row = 1;
	        int nst = n;
	        int nsp = n-2;
	        int nsp2 = n-1; 

	        while (row <= n) {
	        	//work 
	        	//print no. of space 
	        	int i = 1; 
	        	while (i <= nsp2) {
					System.out.print(" " + " ");
					i++; 
				}
				if(row == 1 || row == n) {
					int j = 1; 
					while (j < nst) {
						System.out.print("*" + " ");
						j++; 
					}
				}else {
					System.out.print("*" + " ");
				}
				
				if(row != 1 && row != n) {
					int k = 1;  
					while (k <= nsp) {
						System.out.print(" " + " ");
						k++; 
					}
				}
				System.out.print("*");
				//preparation for next row 
				nsp2--; 
				System.out.println();
				row++;
			}
	    }
}

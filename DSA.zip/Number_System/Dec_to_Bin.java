package com.Number_System;

import java.util.Scanner;

public class Dec_to_Bin {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in); 
		
		int n = scanner.nextInt(); 
		int ans = 0; 
		int mul = 1; 
		while (n != 0) {
			int rem = n % 2; 
			ans = ans + rem * mul; 
			mul *= 10; 
			n /= 2; 
		}
		System.out.println(ans);
	}
}

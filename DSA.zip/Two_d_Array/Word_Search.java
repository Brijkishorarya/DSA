package com.Two_d_Array;

public class Word_Search {
	public static void main(String[] args) {
		char [][] arr = { {'A', 'B', 'C', 'E'},
				          {'S', 'F', 'C', 'S'}, 
				          {'A', 'D', 'E', 'E'} };
		
	}
}

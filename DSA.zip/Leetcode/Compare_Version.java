package com.Leetcode;

public class Compare_Version {
    public static void main(String[] args) {
        String numberAsString = "12300.0450000000"; // Example value
        
        // Convert the string to a double
        double number = Double.parseDouble(numberAsString);
        
        // Convert the double to a string and then format it
        String formattedNumber = String.format("%.2f", number);
        
        System.out.println(formattedNumber); // Output: 12300.05
    }
}



package com.Assignment_4;

import java.util.Scanner;


public class Piyush_and_Magical_Park{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int N = sc.nextInt();
        int M = sc.nextInt();
        int K = sc.nextInt();
        int S = sc.nextInt();

        char[][] park = new char[N][M];
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < M; j++) {
                park[i][j] = sc.next().charAt(0);
            }
        }

        if (canPiyushEscape(park, N, M, K, S)) {
            System.out.println("Yes");
            System.out.println(S);
        } else {
            System.out.println("No");
        }

        sc.close();
    }

    public static boolean canPiyushEscape(char[][] park, int N, int M, int K, int S) {
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < M; j++) {
                if (S < K) {
                    return false;
                }

                char cell = park[i][j];

                if (cell == '.') {
                    S -= 3; // 2 for obstacle and 1 for the step
                } else if (cell == '*') {
                    S += 4; // 5 for magic bean minus 1 for the step
                } else if (cell == '#') {
                    break; // move to the next row
                }

                if (j < M - 1) {
                    S--; // Decrease strength by 1 for the step to the next cell
                }

                if (S < K) {
                    return false;
                }
            }
        }
        return S >= K;
    }
}
